/*
 * Tasks.c
 *
 * Created: 2/23/2019 3:55:33 PM
 *  Author: AVE-LAB-047
 */ 
#include "../DIO/DIO.h"
#include "Tasks.h"
#include "scheduler.h"



void LED1_on(void)
{
DIO_togglePin(LED1);
}

void LED2_on(void)
{
	DIO_togglePin(LED2);
}

void LED3_on(void)
{
	DIO_togglePin(LED3);

}
	
	
	