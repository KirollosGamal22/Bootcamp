/*
 * scheduler.c
 *
 * Created: 2/23/2019 4:14:01 PM
 *  Author: AVE-LAB-047
 */ 
#include "Tasks.h"
#include "scheduler.h"
#include "../Timer0/Timer 0.h"


tasks_struct tasks_arr[MAX_TASKS];

static uint8 task_count=0;	

extern uint8 flag;	
#define ONE 1
#define TRUE 1
#define FALSE 0
#define ZERO 0

/**scheduler_init                                                       *
*Parameters : has no i/p or o/p                                         *
*Description :                                                          *
*function to initialize the scheduler                                   *
************************************************************************/
void scheduler_init(void){
	timer0_init(PRESCALLER_64);  /*initialize the timer 0 with prescaller = 64 */
	timer0_CM_inter_enable();    /*enable the compare match interrupt*/
	enable_global_inter();       /*enable the global interrupt*/
	set_callback(set_flag);      /*set the callback of the ISR to the set flag function*/
}

/**scheduler_start                                                      *
*Parameters : has no i/p or o/p                                         *
*Description :                                                          *
*function to start the scheduler                                        *
************************************************************************/
void scheduler_start(void){
	timer0_start();	             /*start the timer*/
	check_tasks(tasks_arr);      /*call the check task function to adjust the array*/
	prefilled(tasks_arr);        /*call the prefilled function*/
}

/**set_callback                                                         *
*Parameters : has i/p ->>pointer to the function to be called           *
*Description :                                                          *
*function to set the call back in the ISR to a specific function        *
************************************************************************/
void set_callback(void (*ptr)(void)){
	callback_func=ptr;
}

/**set_flag                                                             *
*Parameters : has no i/p or o/p                                         *
*Description :                                                          *
*function to set the flag in the ISR                                    *
************************************************************************/
void set_flag(){
	flag=TRUE;          /*set the flag to high*/
}


/**prefilled                                                            *
*Parameters : has    i/p->> array of structs(tasks)                     *
*Description :                                                          *
*the function of the scheduler                                          *
************************************************************************/
void prefilled (tasks_struct tasks_arr[]){
	uint8 i;
	while(ONE){
		/*remove task 2 if the pushbotton is enabled (remove a task in run time)*/
		if(DIO_ReadPin(PUSH_BOTT1))
		{
			if(!DIO_ReadPin(PUSH_BOTT1))
			{
				scheduler_remove_Task(TASK_2);
			}
		}
		if(TRUE==flag) 
		{
			flag=FALSE; /*if the flag is set to high return it to low again */
			
			for (i=ZERO;i<MAX_TASKS;i++)
			{	    
					if(ZERO==tasks_arr[i].remaining_value) /*if the remaining value =0 so it is the time to execute the task*/
					{
					tasks_arr[i].ptr();	/*execute the task*/
					(tasks_arr[i].remaining_value)=(tasks_arr[i].periodicity); /*return the remaining value to be equal to the periodicity again*/
					}
				(tasks_arr[i].remaining_value)-- ;	/*decrease the remaining value with each tick*/
			}
		}	
		
	}
	
}

/**scheduler_Add_Task                                                   *
*Parameters : has i/p ->> struct(task)                                  *
*Description :                                                          *
*function to add a new task to be called by the scheduler               *
************************************************************************/
uint8 scheduler_Add_Task(tasks_struct task){
	
	if(task_count<MAX_TASKS) /*check if the array of tasks is full*/
	{
		tasks_arr[task_count]=task; /*put the task in its place*/
		task_count++; /*increase the task counter as there is an added task*/
		return TRUE;
	}
	else
	{
		return ZERO;
	}
}

/**scheduler_remove_Task                                                *
*Parameters : has i/p ->> task_num                                      *
*Description :                                                          *
*function to remove existing task to be called by the scheduler         *
************************************************************************/
void scheduler_remove_Task(uint8 task_num){
		uint8 i ;
		for(i=(task_num-ONE);i<task_count;i++) /* start from the task number in the array of tasks till we reach the end of the array*/
		{	
			/*overwrite the next task on the current task in order to remove it*/
			tasks_arr[i].periodicity=tasks_arr[i+ONE].periodicity;
			tasks_arr[i].remaining_value=tasks_arr[i+ONE].remaining_value;
			tasks_arr[i].periority=tasks_arr[i+ONE].periority;
			tasks_arr[i].ptr=tasks_arr[i+ONE].ptr;
		}
		task_count--;
}

/**check_tasks                                                          *
*Parameters : has    i/p->> array of structs(tasks)                     *
*Description :                                                          *
*function to adjust the array of tasks                                  *
************************************************************************/
void check_tasks(tasks_struct tasks_arr[]){
	uint8 j;
	for(j=ZERO;j<MAX_TASKS;j++)
	{
		/*add the periority to the remaining value so there will no collision*/
		tasks_arr[j].remaining_value+=tasks_arr[j].periority; 
	}	
}