/*
 * Operating System.c
 *
 * Created: 2/23/2019 3:54:46 PM
 * Author : AVE-LAB-047
 */ 

#include <avr/io.h>
#include "scheduler/scheduler.h"
#include "scheduler/Tasks.h"
#define INP 0
#define OUT 1
#define PERIOTIRTY_0 0
#define PERIOTIRTY_1 1
#define PERIOTIRTY_2 2
#define NUM_1000 1000
#define NUM_1500 1500
#define NUM_2500 2500
#define NUM_4500 4500
#define NUM_1537 1537
#define PUSH_BOTT1 10
int main(void)
{
	DIO_SetPinDirection(LED1,OUT);
	DIO_SetPinDirection(LED2,OUT);
	DIO_SetPinDirection(LED3,OUT);
	DIO_SetPinDirection(PUSH_BOTT1,INP);
	tasks_struct task1= {LED1_on,NUM_1000,NUM_1000,PERIOTIRTY_0};
	tasks_struct task2 ={LED2_on,NUM_2500,NUM_2500,PERIOTIRTY_1};
	tasks_struct task3 ={LED3_on,NUM_4500,NUM_4500,PERIOTIRTY_2};
	uint8 val,val2,val3;
	val =scheduler_Add_Task(task1);
	val2=scheduler_Add_Task(task2);
	val3=scheduler_Add_Task(task3);
	
	scheduler_init();
	scheduler_start();
    /* Replace with your application code */
    while (ONE) 
    {
	
    }
}

