*
 * Private.h
 *
 * Created: 2/13/2019 9:36:54 AM
 *  Author: AVE-LAB-047
 */ 


#ifndef PRIVATE_H_
#define PRIVATE_H_

typedef enum DIO_ERR_LOGS{
	BAD_ARGUMENT=0,
	SUCCESS=1,
	}DIO_ERR_LOGS;

#endif /* PRIVATE_H_ */