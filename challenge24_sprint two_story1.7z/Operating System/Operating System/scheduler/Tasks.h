/*
 * Tasks.h
 *
 * Created: 2/23/2019 3:55:53 PM
 *  Author: AVE-LAB-047
 */ 


#ifndef TASKS_H_
#define TASKS_H_

#define NUM_TASKS 3
void LED1_on(void);
void LED2_on(void);
void LED3_on(void);





#endif /* TASKS_H_ */