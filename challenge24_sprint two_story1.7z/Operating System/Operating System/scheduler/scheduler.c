/*
 * scheduler.c
 *
 * Created: 2/23/2019 4:14:01 PM
 *  Author: AVE-LAB-047
 */ 
#include "Tasks.h"
#include "scheduler.h"
#include "../Timer0/Timer 0.h"

tasktype tasks[]={LED1_on,LED2_on,LED3_on};
tasktype tasks_arr[MAX_TASKS];
static uint8 task_count=0;	
volatile uint16 count=0;
extern flag;	
#define TRUE 1
#define FALSE 0
#define ZERO 0
/*scheduler init and start function*/
void scheduler_init_start(void){
	timer0_init(PRESCALLER_64);
	timer0_CM_inter_enable();
	enable_global_inter();
	timer0_start();
	set_callback(set_flag);
	prefilled(tasks_arr);
	
}
void set_callback(void (*ptr)(void)){
	callback_func=ptr;
}
void set_flag(){
	flag=TRUE;
}

/*prefilled function*/
void prefilled (tasktype tasks_arr[]){
	uint8 i;
	while (1){
		
		if(flag==TRUE){
			flag=FALSE;
			for (i=ZERO;i<MAX_TASKS;i++)
			{
					increase_count();	
					tasks_arr[i]();	
			}
		}
	}
	
}
void increase_count(void){
	count++;
}

uint8 scheduler_Add_Task(tasktype task){
	
	if(task_count<MAX_TASKS){
	tasks_arr[task_count]=task;
	task_count++;
	return TRUE;
	}
	else{
		return ZERO;
	}
}