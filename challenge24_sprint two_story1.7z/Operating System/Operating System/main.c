/*
 * Operating System.c
 *
 * Created: 2/23/2019 3:54:46 PM
 * Author : AVE-LAB-047
 */ 

#include <avr/io.h>
#include "scheduler/scheduler.h"
#include "scheduler/Tasks.h"
int main(void)
{
	DIO_SetPinDirection(12,1);
	DIO_SetPinDirection(13,1);
	DIO_SetPinDirection(14,1);
	uint8 val,val2,val3;
	val =scheduler_Add_Task(LED1_on);
	val2=scheduler_Add_Task(LED2_on);
	val3=scheduler_Add_Task(LED3_on);
	scheduler_init_start();
    /* Replace with your application code */
    while (1) 
    {
	
    }
}

