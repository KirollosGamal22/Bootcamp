/*
 * Tasks.h
 *
 * Created: 2/23/2019 3:55:53 PM
 *  Author: AVE-LAB-047
 */ 


#ifndef TASKS_H_
#define TASKS_H_

#define NUM_TASKS 3
#define LED1 12
#define LED2 13
#define LED3 14
#define HIGH 1
#define LOW 0
#define ZERO 0
#define ONE_SEC 1000
#define TWO_SEC 2000
#define THREE_SEC 3000
#define FOUR_SEC 4000
#define FIVE_SEC 5000
#define SIX_SEC 6000

void LED1_on(void);
void LED2_on(void);
void LED3_on(void);





#endif /* TASKS_H_ */