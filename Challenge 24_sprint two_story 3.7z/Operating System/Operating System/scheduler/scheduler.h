/*
 * scheduler.h
 *
 * Created: 2/23/2019 3:58:52 PM
 *  Author: AVE-LAB-047
 */ 


#ifndef SCHEDULER_H_
#define SCHEDULER_H_
#include "../DIO/Types.h"
#include "../Timer0/Timer 0.h"
#define MAX_TASKS 3
typedef struct{
	void (*ptr)(void);
	uint16 periodicity ;
	uint16 remaining_value ;
	uint8 periority;
}tasks_struct;
typedef void (*tasktype)(void);

/**scheduler_init                                                       *
*Parameters : has no i/p or o/p                                         *
*Description :                                                          *
*function to initialize the scheduler                                   *
************************************************************************/

void scheduler_init(void);

/**scheduler_start                                                      *
*Parameters : has no i/p or o/p                                         *
*Description :                                                          *
*function to start the scheduler                                        *
************************************************************************/
void scheduler_start(void);

/**prefilled                                                            *
*Parameters : has    i/p->> array of structs(tasks)                     *
*Description :                                                          *
*the function of the scheduler                                          *
************************************************************************/
void prefilled (tasks_struct tasks_arr[]);

/**set_callback                                                         *
*Parameters : has i/p ->>pointer to the function to be called           *
*Description :                                                          *
*function to set the call back in the ISR to a specific function        *
************************************************************************/
void set_callback(void (*ptr)(void));

/**scheduler_Add_Task                                                   *
*Parameters : has i/p ->> struct(task)                                  *
*Description :                                                          *
*function to add a new task to be called by the scheduler               *
************************************************************************/
uint8 scheduler_Add_Task(tasks_struct task);

extern tasktype tasks[];

/**set_flag                                                             *
*Parameters : has no i/p or o/p                                         *
*Description :                                                          *
*function to set the flag in the ISR                                    *
************************************************************************/
void set_flag();
//void increase_count(void);

/**check_tasks                                                          *
*Parameters : has    i/p->> array of structs(tasks)                     *
*Description :                                                          *
*function to adjust the array of tasks                                  *
************************************************************************/
void check_tasks(tasks_struct tasks_arr[]);


#endif /* SCHEDULER_H_ */
