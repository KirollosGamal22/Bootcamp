/*
 * Operating System.c
 *
 * Created: 2/23/2019 3:54:46 PM
 * Author : AVE-LAB-047
 */ 

#include <avr/io.h>
#include "scheduler/scheduler.h"
#include "scheduler/Tasks.h"
#define INP 0
#define OUT 1
#define NUM_1000 1000
#define NUM_1500 1500
#define NUM_2000 2000
#define NUM_4500 4500
#define NUM_1537 1537

int main(void)
{
	DIO_SetPinDirection(LED1,OUT);
	DIO_SetPinDirection(LED2,OUT);
	DIO_SetPinDirection(LED3,OUT);
	tasks_struct task1= {LED1_on,NUM_1000,NUM_1000,1};
	tasks_struct task2 ={LED2_on,NUM_2000,NUM_2000,0};
	tasks_struct task3 ={LED3_on,NUM_4500,NUM_4500,2};
	uint8 val,val2,val3;
	val =scheduler_Add_Task(task1);
	val2=scheduler_Add_Task(task2);
	val3=scheduler_Add_Task(task3);
	
	scheduler_init();
	scheduler_start();
    /* Replace with your application code */
    while (1) 
    {
	
    }
}

